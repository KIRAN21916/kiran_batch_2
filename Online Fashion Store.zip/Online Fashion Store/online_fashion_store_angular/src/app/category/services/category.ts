export class Category {
  category_id: number;
  category_title: string;
  category_description: string;
  category_image_filename: string;
}
export class Company {
  company_id: number;
  company_title: string;
  company_description: string;
  company_image_filename: string;
}
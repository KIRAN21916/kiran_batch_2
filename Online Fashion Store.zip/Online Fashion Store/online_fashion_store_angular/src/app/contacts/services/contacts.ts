export class Contacts {
  contact_id: number;
  contact_name: string;
  contact_email: string;
  contact_subject: string;
  contact_message: string;
}
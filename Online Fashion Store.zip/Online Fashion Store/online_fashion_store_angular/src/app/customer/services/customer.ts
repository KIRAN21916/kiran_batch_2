export class Customer {
  customer_id: number;
  customer_sal: string;
  customer_first_name: string;
  customer_middle_name: string;
  customer_last_name: string;
  customer_gender: string;
  customer_address: string;
  customer_village: string;
  customer_state: string;
  customer_country: string;
  customer_landline: string;
  customer_mobile: string;
  customer_email: string;
  customer_status: string;
  customer_department: string;
  customer_dob: string;
  customer_nationalty: string;
  customer_qualification: string;
  customer_history: string;
  customer_city: string;
  customer_password: string;
}
export class Login {
  login_id: number;
  login_customer_id: string;
  login_email: string;
  login_password: string;
  login_level_id: string;
}
export class Feedback {
  feedback_id: number;
  feedback_name: string;
  feedback_email: string;
  feedback_rating: string;
  feedback_message: string;
}
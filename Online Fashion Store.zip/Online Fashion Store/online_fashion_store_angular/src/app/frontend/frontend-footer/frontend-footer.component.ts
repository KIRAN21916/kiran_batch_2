import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frontend-footer',
  templateUrl: './frontend-footer.component.html',
  styleUrls: ['./frontend-footer.component.css']
})
export class FrontendFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

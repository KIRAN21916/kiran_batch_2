export class Payment {
  payment_id: number;
  payment_customer_id: string;
  payment_date: string;
  payment_amount: number;
}
export class Orders {
  order_id: number;
  order_customer_id: number;
  order_total: number;
  order_status: string;
  order_date: string;
  customer_mobile: string;
  customer_name: string;
}
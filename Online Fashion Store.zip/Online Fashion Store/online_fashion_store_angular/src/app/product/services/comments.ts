export class Comments {
  comments_id: number;
  comments_product_id: string;
  comments_user_id: string;
  comments_title: string;
  comments_date: string;
  comments_description: string;
}
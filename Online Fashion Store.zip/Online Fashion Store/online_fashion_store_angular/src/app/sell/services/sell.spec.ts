import { Sell } from './sell';

describe('Sell', () => {
  it('should create an instance', () => {
    expect(new Sell()).toBeTruthy();
  });
});

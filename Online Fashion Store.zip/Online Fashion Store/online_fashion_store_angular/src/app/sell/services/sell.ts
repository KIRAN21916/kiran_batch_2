export class Sell {
  sell_id: number;
  sell_order_id: number;
  sell_product_id: number;
  sell_units: number;
  sell_price_per_unit: number;
  sell_total_cost: number;
}